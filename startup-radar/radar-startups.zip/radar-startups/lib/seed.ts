import type { EventItem, Reco, WatchItem } from "./types";

// Recherche du 29 septembre 2026 (sources dans chaque fiche). Mise à jour ensuite par l'app.
export const SEED_WATCHLIST: WatchItem[] = [
  {
    "id": "anthropic",
    "arr": 47,
    "country": "US",
    "cur": "$",
    "date": "2026-05",
    "growth": "Revenu annualisé de 47 Md$ en mai 2026, 11,5 Md$ de chiffre d'affaires au 2e trimestre 2026 (environ 10 Md$ sur toute l'année 2025). IPO visée autour de 2 000 Md$ de valorisation.",
    "how": "Pas accessible avant l'IPO pour un particulier en France. Après la cotation : compte-titres ordinaire. Stratégie prudente : attendre quelques semaines après l'introduction.",
    "name": "Anthropic",
    "next": "IPO repoussée à novembre 2026",
    "noScore": true,
    "profil": "Licorne privée",
    "risks": "Valorisation visée (~2 000 Md$) très élevée. Concurrence frontale avec OpenAI, Google et d'autres. Coûts de calcul énormes. Premiers jours de cotation probablement très volatils.",
    "round": "Série H",
    "sector": "IA",
    "src": "https://www.fool.com/investing/2026/09/26/anthropic-s-ipo-was-just-delayed-to-november-here-s-the-one-number-that-has-me-even-more-excited/",
    "srcl": "Motley Fool, 26 sept. 2026",
    "status": "ipo",
    "updated": "2026-09-29",
    "val": 965,
    "verdict": "Non notée : je suis développé par Anthropic, conflit d'intérêts. Règle générale pour toute IPO : attendre au moins 30 jours après la cotation.",
    "why": "Croissance du revenu parmi les plus rapides jamais vues pour une entreprise de cette taille. Sera probablement l'une des plus grosses IPO de 2026. Attention : Claude, l'assistant qui a préparé ce tableau, est développé par Anthropic. Je suis donc en conflit d'intérêts sur cette ligne, fais ta propre analyse.",
    "ticker": null
  },
  {
    "id": "biolevate",
    "arr": null,
    "country": "FR",
    "cur": "€",
    "date": "2026-09",
    "growth": "Plus grosse levée française de la semaine du 21 sept. 2026, avec EQT Ventures, Orange Ventures, Raise, MSD.",
    "how": "Non accessible directement. Les pépites françaises de ce stade passent parfois par des FCPI ou du crowdequity lors de tours plus tardifs.",
    "name": "Biolevate",
    "next": "",
    "profil": "Early-stage Europe",
    "risks": "Jeune entreprise, chiffre d'affaires non publié.",
    "round": "30 M€",
    "score": {
      "acces": 1,
      "croissance": 2,
      "marche": 3,
      "solidite": 3,
      "sortie": 1,
      "valo": 3
    },
    "sector": "IA santé",
    "src": "https://www.maddyness.com/2026/09/25/les-startups-francaises-ont-leve-114-millions-deuros-cette-semaine-dont-90-millions-dans-lia/",
    "srcl": "Maddyness, 25 sept. 2026",
    "status": "suivre",
    "updated": "2026-09-29",
    "val": null,
    "verdict": "Bon profil de future pépite FR. Guetter un éventuel tour ouvert aux particuliers.",
    "why": "Agents d'IA pour les laboratoires pharmaceutiques et biotech. Investisseurs de premier plan.",
    "ticker": null
  },
  {
    "id": "cerebras",
    "arr": null,
    "country": "US",
    "cur": "$",
    "date": "2026-05",
    "growth": "Cotée au Nasdaq le 14 mai 2026 à 185 $ l'action. A dépassé 300 $ puis est revenue à son prix d'introduction fin août.",
    "how": "Compte-titres, Nasdaq (ticker CBRS).",
    "name": "Cerebras",
    "next": "",
    "profil": "Coté (post-IPO)",
    "risks": "Coûts énormes de centres de données, concurrence de Nvidia et des puces maison des géants. Titre très volatil.",
    "round": "IPO 5,55 Md$",
    "score": {
      "acces": 5,
      "croissance": 4,
      "marche": 4,
      "solidite": 3,
      "sortie": 5,
      "valo": 2
    },
    "sector": "IA / puces",
    "src": "https://www.superhero.com.au/learn/upcoming-ipos-2026/",
    "srcl": "Superhero, IPO 2026",
    "status": "acces",
    "updated": "2026-09-29",
    "val": null,
    "verdict": "Option satellite, petite ligne. Illustre pourquoi attendre après une IPO.",
    "why": "Puces spécialisées pour faire tourner l'IA, alternative à Nvidia. Après la retombée, on peut l'acheter au prix d'IPO plutôt qu'au sommet.",
    "ticker": "CBRS"
  },
  {
    "id": "cyera",
    "arr": null,
    "country": "US",
    "cur": "$",
    "date": "2026-09",
    "growth": "2,7 Md$ levés au total.",
    "how": "Non accessible aux particuliers.",
    "name": "Cyera",
    "next": "",
    "profil": "Licorne privée",
    "risks": "A énormément levé : la barre de sortie est très haute pour les derniers entrants.",
    "round": "400 M$ série G",
    "score": {
      "acces": 1,
      "croissance": 3,
      "marche": 4,
      "solidite": 4,
      "sortie": 3,
      "valo": 2
    },
    "sector": "Cybersécurité",
    "src": "https://news.crunchbase.com/venture/biggest-funding-rounds-cybersecurity-ai-health-island-cyera/",
    "srcl": "Crunchbase News, 25 sept. 2026",
    "status": "suivre",
    "updated": "2026-09-29",
    "val": null,
    "verdict": "Suivre.",
    "why": "Sécurise les données des entreprises face aux humains et aux agents d'IA : besoin qui grandit avec l'IA.",
    "ticker": null
  },
  {
    "id": "databricks",
    "arr": 4.8,
    "country": "US",
    "cur": "$",
    "date": "2026-09",
    "growth": "Revenu annualisé de plus de 4,8 Md$, +55 % sur un an. Environ 28 fois le revenu.",
    "how": "Pas d'accès direct. Indirectement via Scottish Mortgage, ou via un club type Blast (licornes pré-IPO, dès 500 € avec frais).",
    "name": "Databricks",
    "next": "IPO non datée",
    "profil": "Licorne privée",
    "risks": "Pas d'IPO datée. Concurrence de Snowflake et des clouds.",
    "round": "4 Md$+",
    "score": {
      "acces": 2,
      "croissance": 4,
      "marche": 5,
      "solidite": 5,
      "sortie": 3,
      "valo": 2
    },
    "sector": "IA / données",
    "src": "https://www.superhero.com.au/learn/upcoming-ipos-2026/",
    "srcl": "Superhero, IPO 2026",
    "status": "suivre",
    "updated": "2026-09-29",
    "val": 134,
    "verdict": "La licorne privée la plus solide de la liste. Exposition via SMT en attendant.",
    "why": "Plateforme de données et d'IA utilisée par une grande partie des grandes entreprises. Rare combinaison taille + croissance.",
    "ticker": null
  },
  {
    "id": "dxyz",
    "arr": null,
    "country": "US",
    "cur": "$",
    "date": "2026-09",
    "growth": "31,31 $ le 18 sept. 2026 pour une valeur d'actifs de 34,30 $ : décote de 9 %. 36 sociétés en portefeuille (SpaceX, OpenAI, Anthropic…), mais 31 % en trésorerie au 31 mars.",
    "how": "Seulement si ton courtier le permet. Sinon, préférer Scottish Mortgage.",
    "name": "Destiny Tech100 (DXYZ)",
    "next": "",
    "profil": "Véhicule coté pré-IPO",
    "risks": "Historiquement très volatil, a longtemps coté avec une énorme prime. Beaucoup de trésorerie qui ne travaille pas. Fonds américain souvent non achetable depuis un courtier européen (règles européennes sur les documents d'information).",
    "round": "Coté à New York",
    "score": {
      "acces": 2,
      "croissance": 3,
      "marche": 4,
      "solidite": 2,
      "sortie": 4,
      "valo": 3
    },
    "sector": "Fonds coté / licornes",
    "src": "https://www.cefconnect.com/fund/DXYZ",
    "srcl": "CEF Connect",
    "status": "acces",
    "updated": "2026-09-29",
    "val": null,
    "verdict": "Plan B à Scottish Mortgage, petite ligne, si accessible.",
    "why": "Exposition directe à SpaceX, OpenAI et Anthropic en un seul titre, actuellement moins cher que ses actifs.",
    "ticker": "DXYZ"
  },
  {
    "id": "hackuity",
    "arr": null,
    "country": "FR",
    "cur": "€",
    "date": "2026-09",
    "growth": "Basée à Lyon.",
    "how": "Non accessible directement.",
    "name": "Hackuity",
    "next": "",
    "profil": "Early-stage Europe",
    "risks": "Petite taille face aux géants américains de la cyber.",
    "round": "16 M€",
    "score": {
      "acces": 1,
      "croissance": 2,
      "marche": 3,
      "solidite": 2,
      "sortie": 1,
      "valo": 3
    },
    "sector": "Cybersécurité",
    "src": "https://www.frenchweb.fr/les-levees-de-fonds-de-la-french-tech-du-14-au-18-septembre-2026-422-millions-deuros-lia-capte-82-des-capitaux/463537",
    "srcl": "FrenchWeb, sept. 2026",
    "status": "suivre",
    "updated": "2026-09-29",
    "val": null,
    "verdict": "Suivre.",
    "why": "Automatise la correction des failles de sécurité : même tendance de fond que Island et Cyera, à l'échelle française.",
    "ticker": null
  },
  {
    "id": "island",
    "arr": null,
    "country": "US",
    "cur": "$",
    "date": "2026-09",
    "growth": "Valorisation 6,4 Md$, plus du double de 2024.",
    "how": "Non accessible aux particuliers. Candidate IPO à moyen terme.",
    "name": "Island",
    "next": "",
    "profil": "Licorne privée",
    "risks": "Doit convaincre les grands comptes de changer de navigateur. Concurrence de Google et Microsoft.",
    "round": "400 M$ série F",
    "score": {
      "acces": 1,
      "croissance": 3,
      "marche": 4,
      "solidite": 4,
      "sortie": 3,
      "valo": 3
    },
    "sector": "Cybersécurité",
    "src": "https://news.crunchbase.com/venture/biggest-funding-rounds-cybersecurity-ai-health-island-cyera/",
    "srcl": "Crunchbase News, 25 sept. 2026",
    "status": "suivre",
    "updated": "2026-09-29",
    "val": 6.4,
    "verdict": "Future candidate IPO cyber. Suivre.",
    "why": "Navigateur sécurisé pour entreprises. La cybersécurité reste l'un des budgets que les entreprises coupent le moins.",
    "ticker": null
  },
  {
    "id": "kraken",
    "arr": null,
    "country": "US",
    "cur": "$",
    "date": "2026-09",
    "growth": "Dossier d'IPO confidentiel déposé il y a près d'un an puis mis en pause. Le PDG se dit « prêt à 80 % » pour 2026, report possible en 2027.",
    "how": "Surveiller l'annonce d'IPO.",
    "name": "Kraken",
    "next": "IPO fin 2026 ou 2027",
    "profil": "Licorne privée",
    "risks": "Revenus très dépendants du cours des cryptos et du volume d'échanges. Calendrier incertain.",
    "round": "—",
    "score": {
      "acces": 1,
      "croissance": 2,
      "marche": 3,
      "solidite": 3,
      "sortie": 3,
      "valo": 3
    },
    "sector": "Crypto",
    "src": "https://news.crunchbase.com/public/startups-to-watch-ipo-ai-chips-fintech-2026/",
    "srcl": "Crunchbase News, 2 sept. 2026",
    "status": "ipo",
    "updated": "2026-09-29",
    "val": null,
    "verdict": "Pari sur la crypto plus que sur une startup. Pas prioritaire.",
    "why": "Grande plateforme d'échange crypto, alternative à Coinbase en bourse.",
    "ticker": null
  },
  {
    "id": "lovable",
    "arr": 0.2,
    "country": "SE",
    "cur": "$",
    "date": "2026-08",
    "growth": "Valorisation 1,8 Md$ (fév. 2025) → 6,6 Md$ (déc. 2025) → 13,3 Md$ (août 2026). 200 M$ de revenu récurrent dès novembre 2025 (chiffre plus récent non publié, le multiple affiché est donc surestimé).",
    "how": "Non accessible aux particuliers.",
    "name": "Lovable",
    "next": "",
    "profil": "Licorne privée",
    "risks": "Marché de « l'IA qui code » très encombré (Cursor, Replit, les géants). Clients souvent individuels qui peuvent partir vite.",
    "round": "400 M$ série C",
    "score": {
      "acces": 1,
      "croissance": 5,
      "marche": 4,
      "solidite": 3,
      "sortie": 2,
      "valo": 2
    },
    "sector": "IA / code",
    "src": "https://en.wikipedia.org/wiki/Lovable_(company)",
    "srcl": "Wikipedia",
    "status": "suivre",
    "updated": "2026-09-29",
    "val": 13.3,
    "verdict": "Croissance spectaculaire mais marché très disputé. Suivre.",
    "why": "Une des croissances les plus rapides d'Europe : de 1 M$ à 100 M$ de revenu récurrent en 8 mois. Permet de créer une appli en décrivant ce qu'on veut.",
    "ticker": null
  },
  {
    "id": "micro1",
    "arr": null,
    "country": "US",
    "cur": "$",
    "date": "2026-09",
    "growth": "Levée rapportée par Forbes, à confirmer.",
    "how": "Non accessible aux particuliers.",
    "name": "Micro1",
    "next": "",
    "profil": "Licorne privée",
    "risks": "Chiffres non officiels. Clients concentrés.",
    "round": "100 M$+",
    "score": {
      "acces": 1,
      "croissance": 4,
      "marche": 3,
      "solidite": 2,
      "sortie": 2,
      "valo": 2
    },
    "sector": "IA / données",
    "src": "https://news.crunchbase.com/venture/biggest-funding-rounds-cybersecurity-ai-health-island-cyera/",
    "srcl": "Crunchbase News, 25 sept. 2026",
    "status": "suivre",
    "updated": "2026-09-29",
    "val": 4,
    "verdict": "Chiffres non officiels : prudence.",
    "why": "Fournit des données d'entraînement aux grands labos d'IA, comme Snorkel.",
    "ticker": null
  },
  {
    "id": "mistral",
    "arr": null,
    "country": "FR",
    "cur": "€",
    "date": "2026-09",
    "growth": "Valorisation passée de 11,7 Md€ à environ 21 Md€ en moins d'un an. Revenu récurrent au-delà de 400 M$ en janvier 2026, objectif 1 Md$ fin 2026.",
    "how": "Non accessible aux particuliers pour l'instant (société privée). À suivre pour une future IPO, probablement à Paris ou New York.",
    "name": "Mistral AI",
    "next": "",
    "profil": "Licorne privée",
    "risks": "Fait face à des concurrents américains qui lèvent 10 à 50 fois plus. Valorisation d'environ 20 à 25 fois le revenu visé.",
    "round": "3 Md€",
    "score": {
      "acces": 1,
      "croissance": 5,
      "marche": 5,
      "solidite": 4,
      "sortie": 2,
      "valo": 2
    },
    "sector": "IA",
    "src": "https://siecledigital.fr/2026/09/08/mistral-ai-leve-3-milliards-deuros-et-voit-sa-valorisation-presque-doubler-en-un-an/",
    "srcl": "Siècle Digital, 8 sept. 2026",
    "status": "suivre",
    "updated": "2026-09-29",
    "val": 21,
    "verdict": "Le champion français à suivre de près. Rien à acheter aujourd'hui.",
    "why": "Champion européen de l'IA, soutenu par l'UE (Scaleup Europe Fund), Samsung, BlackRock. Argument de souveraineté pour les entreprises et États européens.",
    "ticker": null
  },
  {
    "id": "notion",
    "arr": null,
    "country": "US",
    "cur": "$",
    "date": "2026-09",
    "growth": "Valorisée 11 Md$, un peu plus de 343 M$ levés seulement (très économe en capital). Forte croissance tirée par ses offres d'IA pour entreprises.",
    "how": "Surveiller l'annonce d'IPO.",
    "name": "Notion",
    "next": "IPO possible sous 6 mois",
    "profil": "Licorne privée",
    "risks": "Marché de la productivité très concurrentiel (Microsoft, Google). L'IA peut aussi rendre ses fonctions faciles à copier.",
    "round": "—",
    "score": {
      "acces": 1,
      "croissance": 3,
      "marche": 4,
      "solidite": 5,
      "sortie": 4,
      "valo": 3
    },
    "sector": "Logiciel / productivité",
    "src": "https://news.crunchbase.com/public/startups-to-watch-ipo-ai-chips-fintech-2026/",
    "srcl": "Crunchbase News, 2 sept. 2026",
    "status": "ipo",
    "updated": "2026-09-29",
    "val": 11,
    "verdict": "Une des IPO à venir les plus saines (peu de capital brûlé). Surveiller.",
    "why": "A levé peu d'argent pour sa taille : signe d'un modèle efficace. Candidate sérieuse à une IPO proche selon Crunchbase.",
    "ticker": null
  },
  {
    "id": "openevidence",
    "arr": null,
    "country": "US",
    "cur": "$",
    "date": "2026-09",
    "growth": "Valorisée 12 Md$. Plateforme d'IA utilisée par les médecins.",
    "how": "Surveiller l'annonce d'IPO.",
    "name": "OpenEvidence",
    "next": "IPO après OpenAI / Anthropic",
    "profil": "Licorne privée",
    "risks": "Le PDG attend que OpenAI et Anthropic soient cotées avant de se lancer : calendrier incertain. Régulation santé.",
    "round": "—",
    "score": {
      "acces": 1,
      "croissance": 4,
      "marche": 4,
      "solidite": 3,
      "sortie": 3,
      "valo": 2
    },
    "sector": "IA santé",
    "src": "https://news.crunchbase.com/public/startups-to-watch-ipo-ai-chips-fintech-2026/",
    "srcl": "Crunchbase News, 2 sept. 2026",
    "status": "ipo",
    "updated": "2026-09-29",
    "val": 12,
    "verdict": "Surveiller, IPO pas avant celles d'OpenAI et Anthropic.",
    "why": "IA spécialisée dans un secteur (la médecine) où la confiance et les données sont une barrière à l'entrée.",
    "ticker": null
  },
  {
    "id": "oura",
    "arr": null,
    "country": "FI / US",
    "cur": "$",
    "date": "2026-09",
    "growth": "Valorisée plus de 11 Md$, 1,5 Md$ levés au total.",
    "how": "Surveiller l'annonce d'IPO. Pas accessible avant.",
    "name": "Oura",
    "next": "IPO envisagée automne 2026",
    "profil": "Licorne privée",
    "risks": "Matériel grand public : marges plus faibles que le logiciel, concurrence de Samsung et Apple.",
    "round": "—",
    "score": {
      "acces": 1,
      "croissance": 3,
      "marche": 3,
      "solidite": 4,
      "sortie": 4,
      "valo": 3
    },
    "sector": "Santé connectée",
    "src": "https://news.crunchbase.com/public/startups-to-watch-ipo-ai-chips-fintech-2026/",
    "srcl": "Crunchbase News, 2 sept. 2026",
    "status": "ipo",
    "updated": "2026-09-29",
    "val": 11,
    "verdict": "Surveiller l'IPO, puis attendre 30 jours.",
    "why": "Bague connectée leader de son marché, produit grand public rentable à l'unité. Crunchbase la classe parmi les candidates probables à une IPO dans les 6 mois.",
    "ticker": null
  },
  {
    "id": "precision",
    "arr": null,
    "country": "US",
    "cur": "$",
    "date": "2026-09",
    "growth": "Menée par Pershing Square (Bill Ackman).",
    "how": "Non accessible aux particuliers.",
    "name": "Precision Neuroscience",
    "next": "",
    "profil": "Licorne privée",
    "risks": "Encore au stade clinique : pas de revenus significatifs, validation réglementaire longue.",
    "round": "250 M$ série D",
    "score": {
      "acces": 1,
      "croissance": 1,
      "marche": 3,
      "solidite": 3,
      "sortie": 1,
      "valo": 2
    },
    "sector": "Neurotech",
    "src": "https://news.crunchbase.com/venture/biggest-funding-rounds-cybersecurity-ai-health-island-cyera/",
    "srcl": "Crunchbase News, 25 sept. 2026",
    "status": "suivre",
    "updated": "2026-09-29",
    "val": null,
    "verdict": "Pari scientifique très long terme. Pour curiosité seulement.",
    "why": "Interfaces cerveau-ordinateur, concurrent de Neuralink. Pari de très long terme.",
    "ticker": null
  },
  {
    "id": "ramp",
    "arr": null,
    "country": "US",
    "cur": "$",
    "date": "2026-06",
    "growth": "Valorisée 44 Md$ en juin 2026.",
    "how": "Non accessible aux particuliers.",
    "name": "Ramp",
    "next": "",
    "profil": "Licorne privée",
    "risks": "Revenus liés aux commissions sur carte : sensibles au ralentissement économique.",
    "round": "750 M$",
    "score": {
      "acces": 1,
      "croissance": 4,
      "marche": 4,
      "solidite": 4,
      "sortie": 3,
      "valo": 2
    },
    "sector": "Fintech",
    "src": "https://en.wikipedia.org/wiki/Ramp_(company)",
    "srcl": "Wikipedia",
    "status": "suivre",
    "updated": "2026-09-29",
    "val": 44,
    "verdict": "Suivre.",
    "why": "Cartes et gestion des dépenses pour entreprises, une des fintechs à la croissance la plus rapide.",
    "ticker": null
  },
  {
    "id": "revolut",
    "arr": null,
    "country": "UK",
    "cur": "$",
    "date": "2026-09",
    "growth": "Valorisée environ 75 Md$ lors d'une vente d'actions secondaire. Avance vers une licence bancaire britannique complète.",
    "how": "Via un club type Blast (licornes pré-IPO) uniquement.",
    "name": "Revolut",
    "next": "IPO vers 2028",
    "profil": "Licorne privée",
    "risks": "La direction évoque plutôt 2028 pour l'IPO. Régulation bancaire lourde.",
    "round": "Cession secondaire",
    "score": {
      "acces": 2,
      "croissance": 4,
      "marche": 4,
      "solidite": 4,
      "sortie": 2,
      "valo": 3
    },
    "sector": "Fintech / néobanque",
    "src": "https://www.allocations.com/insights/spacex-openai-anthropic-stripe-databricks-ipo-timeline-2026",
    "srcl": "Allocations, calendrier IPO 2026",
    "status": "suivre",
    "updated": "2026-09-29",
    "val": 75,
    "verdict": "Suivre, horizon long.",
    "why": "Néobanque européenne dominante, pourrait devenir la plus grosse IPO tech de Londres.",
    "ticker": null
  },
  {
    "id": "scottish-mortgage",
    "arr": null,
    "country": "UK",
    "cur": "$",
    "date": "2026-09",
    "growth": "Environ 1 500 pence l'action le 9 sept. 2026. SpaceX est la 1re ligne du portefeuille, Anthropic pèse 2,8 %. Détient aussi Databricks et ByteDance, soit 7 des 10 plus grosses sociétés privées au monde.",
    "how": "Compte-titres ordinaire, marché de Londres (ticker SMT). Vérifie les frais annuels dans le document d'informations clés.",
    "name": "Scottish Mortgage (SMT)",
    "next": "",
    "profil": "Véhicule coté pré-IPO",
    "risks": "Très concentré sur la tech de croissance : chute forte si le secteur corrige. Une IPO d'Anthropic décevante ferait baisser la valeur du fonds. Peut coter avec une décote ou une prime par rapport à la valeur de ses actifs.",
    "round": "Coté à Londres",
    "score": {
      "acces": 5,
      "croissance": 3,
      "marche": 4,
      "solidite": 4,
      "sortie": 5,
      "valo": 3
    },
    "sector": "Fonds coté / licornes",
    "src": "https://invezz.com/news/2026/09/09/scottish-mortgage-shares-hit-crucial-price-amid-spacex-anthropic-catalysts/",
    "srcl": "Invezz, 9 sept. 2026",
    "status": "acces",
    "updated": "2026-09-29",
    "val": null,
    "verdict": "Ma 1re priorité : le cœur du budget startups (environ 40 %).",
    "why": "Le moyen le plus simple et le moins cher d'être exposé à un panier de licornes (dont certaines non cotées) avec un compte-titres, et de pouvoir revendre à tout moment.",
    "ticker": "SMT.L"
  },
  {
    "id": "snorkel",
    "arr": 0.375,
    "country": "US",
    "cur": "$",
    "date": "2026-09",
    "growth": "Plus de 375 M$ de revenu récurrent pour une valorisation de 3,2 Md$ : environ 8,5 fois le revenu.",
    "how": "Non accessible aux particuliers.",
    "name": "Snorkel AI",
    "next": "",
    "profil": "Licorne privée",
    "risks": "Clients très concentrés (quelques grands labos). Concurrence de Scale AI, Micro1, etc.",
    "round": "350 M$ série E",
    "score": {
      "acces": 1,
      "croissance": 3,
      "marche": 4,
      "solidite": 3,
      "sortie": 2,
      "valo": 4
    },
    "sector": "IA / données",
    "src": "https://news.crunchbase.com/venture/biggest-funding-rounds-cybersecurity-ai-health-island-cyera/",
    "srcl": "Crunchbase News, 25 sept. 2026",
    "status": "suivre",
    "updated": "2026-09-29",
    "val": 3.2,
    "verdict": "Un des prix les plus raisonnables de l'IA. À surveiller pour une IPO future.",
    "why": "Fournit les données d'entraînement aux laboratoires d'IA. Multiple nettement plus raisonnable que la plupart des startups d'IA.",
    "ticker": null
  },
  {
    "id": "spacex",
    "arr": null,
    "country": "US",
    "cur": "$",
    "date": "2026-06",
    "growth": "IPO le 12 juin 2026 à 135 $ (1er jour : 161 $). Sommet vers 226 $, puis passage sous le prix d'IPO mi-juillet. 147,28 $ le 28 sept. 2026 : -35 % depuis le sommet, +9 % au-dessus du prix d'IPO. A racheté Cursor pour 60 Md$ (août 2026).",
    "how": "Trade Republic, compte-titres, ticker SPCX, fractions d'action possibles, 1 € par ordre. Pas de PEA.",
    "name": "SpaceX (+ Cursor)",
    "next": "Fin du blocage dès déc. 2026",
    "profil": "Coté (post-IPO)",
    "risks": "Valorisation énorme. Levée progressive du blocage des investisseurs d'avant l'IPO à partir d'environ 180 jours (début décembre 2026) : beaucoup d'actions peuvent être vendues d'un coup. Emprunt obligataire de 25 Md$. Échecs de lancement récents. Musk et les dirigeants bloqués 366 jours (juin 2027).",
    "round": "IPO 75 Md$ (record)",
    "score": {
      "acces": 5,
      "croissance": 4,
      "marche": 5,
      "solidite": 5,
      "sortie": 5,
      "valo": 1
    },
    "sector": "Spatial / IA",
    "src": "https://www.fool.com/investing/2026/07/27/spacex-stock-plummets-50-below-its-post-ipo-high-h/",
    "srcl": "Motley Fool, 27 juil. 2026 + Wikipedia",
    "status": "acces",
    "updated": "2026-09-29",
    "val": 1770,
    "verdict": "A déjà beaucoup baissé mais le risque de décembre reste. Acheter un tiers maintenant, le reste après la levée du blocage.",
    "why": "Seul moyen coté d'être exposé à la fois au spatial (Starlink, lanceurs) et à Cursor, l'un des logiciels à la croissance la plus rapide de l'histoire. Accessible dès aujourd'hui avec un simple compte-titres.",
    "ticker": "SPCX"
  },
  {
    "id": "stripe",
    "arr": null,
    "country": "US",
    "cur": "$",
    "date": "2026-02",
    "growth": "Valorisée 159 Md$ lors d'une offre de rachat en février 2026. 10,4 Md$ levés au total.",
    "how": "Via un club type Blast (licornes pré-IPO) uniquement.",
    "name": "Stripe",
    "next": "Pas d'IPO prévue",
    "profil": "Licorne privée",
    "risks": "Aucune urgence à entrer en bourse : l'attente peut durer des années.",
    "round": "Rachat d'actions salariés",
    "score": {
      "acces": 2,
      "croissance": 3,
      "marche": 5,
      "solidite": 5,
      "sortie": 2,
      "valo": 3
    },
    "sector": "Fintech / paiements",
    "src": "https://www.allocations.com/insights/spacex-openai-anthropic-stripe-databricks-ipo-timeline-2026",
    "srcl": "Allocations, calendrier IPO 2026",
    "status": "suivre",
    "updated": "2026-09-29",
    "val": 159,
    "verdict": "Solide mais patience requise. Surveiller.",
    "why": "L'entreprise la plus solide de la génération pré-IPO selon plusieurs analystes : rentable, infrastructure de paiement d'Internet.",
    "ticker": null
  },
  {
    "id": "temporal",
    "arr": null,
    "country": "US",
    "cur": "$",
    "date": "2026-09",
    "growth": "Plus grosse levée américaine de la semaine du 18 sept. 2026.",
    "how": "Non accessible aux particuliers.",
    "name": "Temporal",
    "next": "",
    "profil": "Licorne privée",
    "risks": "Produit technique basé sur de l'open source : monétisation à surveiller.",
    "round": "550 M$ série E",
    "score": {
      "acces": 1,
      "croissance": 3,
      "marche": 4,
      "solidite": 4,
      "sortie": 2,
      "valo": 2
    },
    "sector": "IA / infrastructure",
    "src": "https://news.crunchbase.com/venture/biggest-funding-rounds-ai-space-fintech-temporal/",
    "srcl": "Crunchbase News, 18 sept. 2026",
    "status": "suivre",
    "updated": "2026-09-29",
    "val": 12.55,
    "verdict": "Suivre.",
    "why": "Infrastructure qui fait tourner de façon fiable les applications et agents d'IA. Ce type de brique profite de la croissance de tout le secteur.",
    "ticker": null
  },
  {
    "id": "wealthcome",
    "arr": null,
    "country": "FR",
    "cur": "€",
    "date": "2026-09",
    "growth": "Menée par Breega et Blackfin.",
    "how": "Non accessible directement.",
    "name": "Wealthcome",
    "next": "",
    "profil": "Early-stage Europe",
    "risks": "Marché de niche, dépend des cabinets de conseil.",
    "round": "15 M€ série B",
    "score": {
      "acces": 1,
      "croissance": 2,
      "marche": 2,
      "solidite": 3,
      "sortie": 1,
      "valo": 3
    },
    "sector": "Fintech",
    "src": "https://www.maddyness.com/2026/09/25/les-startups-francaises-ont-leve-114-millions-deuros-cette-semaine-dont-90-millions-dans-lia/",
    "srcl": "Maddyness, 25 sept. 2026",
    "status": "suivre",
    "updated": "2026-09-29",
    "val": null,
    "verdict": "Suivre.",
    "why": "Gestion de patrimoine enrichie par l'IA pour les conseillers.",
    "ticker": null
  }
];

export const SEED_EVENTS: EventItem[] = [
  {
    "id": "e11",
    "date": "2026-05-14",
    "type": "IPO",
    "what": "Cotée au Nasdaq à 185 $ (5,55 Md$ levés). Au-dessus de 300 $, puis retour au prix d'IPO fin août.",
    "who": "Cerebras"
  },
  {
    "id": "e9",
    "date": "2026-06-12",
    "type": "IPO",
    "what": "Introduction en bourse : 75 Md$ levés à environ 1 770 Md$ de valorisation, record historique.",
    "who": "SpaceX"
  },
  {
    "id": "e14",
    "date": "2026-07-15",
    "type": "Autre",
    "what": "L'action passe sous son prix d'IPO (135 $) pour la première fois, après un sommet vers 226 $.",
    "who": "SpaceX"
  },
  {
    "id": "e8",
    "date": "2026-08-01",
    "type": "Levée",
    "what": "400 M$ en série C à 13,3 Md$ de valorisation (août 2026).",
    "who": "Lovable"
  },
  {
    "id": "e7",
    "date": "2026-08-14",
    "type": "Rachat",
    "what": "SpaceX finalise le rachat d'Anysphere (Cursor) pour 60 Md$ en actions.",
    "who": "SpaceX / Cursor"
  },
  {
    "id": "e6",
    "date": "2026-09-08",
    "type": "Levée",
    "what": "3 Md€ levés, valorisation d'environ 21 Md€ (quasi doublée en un an).",
    "who": "Mistral AI"
  },
  {
    "id": "e5",
    "date": "2026-09-18",
    "type": "Levée",
    "what": "550 M$ en série E à 12,55 Md$ de valorisation.",
    "who": "Temporal"
  },
  {
    "id": "e2",
    "date": "2026-09-25",
    "type": "Levée",
    "what": "Deux levées de 400 M$ en cybersécurité. Island valorisée 6,4 Md$.",
    "who": "Island / Cyera"
  },
  {
    "id": "e3",
    "date": "2026-09-25",
    "type": "Levée",
    "what": "350 M$ à 3,2 Md$ de valorisation, plus de 375 M$ de revenu récurrent.",
    "who": "Snorkel AI"
  },
  {
    "id": "e4",
    "date": "2026-09-25",
    "type": "Levée",
    "what": "114 M€ levés en 16 opérations dans la semaine, dont 90 M€ dans l'IA (Biolevate 30 M€).",
    "who": "French Tech"
  },
  {
    "id": "e10",
    "date": "2026-09-30",
    "type": "Autre",
    "what": "Fin de la réduction d'impôt IR-PME à 25 % pour les entreprises solidaires (ESUS). Le taux général reste 18 %.",
    "who": "Fiscalité FR"
  },
  {
    "id": "e1",
    "date": "2026-11-15",
    "type": "IPO",
    "what": "Introduction en bourse repoussée d'octobre à novembre 2026 (date exacte non fixée), valorisation visée ~2 000 Md$.",
    "who": "Anthropic"
  },
  {
    "id": "e13",
    "date": "2026-12-09",
    "type": "Autre",
    "what": "Début de la levée du blocage (180 jours, échelonnée) pour les investisseurs d'avant l'IPO : pression vendeuse possible. Moment pour acheter le reste de ta ligne.",
    "who": "SpaceX"
  },
  {
    "id": "e12",
    "date": "2027-01-01",
    "type": "IPO",
    "what": "IPO repoussée à 2027 selon la directrice financière (dossier confidentiel déposé le 8 juin 2026). Date exacte inconnue.",
    "who": "OpenAI"
  }
];

// Analyse de départ (recherche du 29/09/2026), affichée tant que l'analyse automatique n'a pas tourné.
export const SEED_RECO: Reco = {
  "resume": "Tu as 5 000 € à placer seul. Priorité : entrer petit à petit sur SpaceX, qui a déjà perdu 35 % depuis son sommet, prendre une petite ligne Cerebras, garder 1 000 € pour les prochaines entrées en bourse et démarrer ta sélection de startups françaises. Rien ne presse : étale tes achats.",
  "marche": "Les introductions en bourse de 2026 ont été euphoriques puis ont corrigé : SpaceX est passée de 226 $ à 145 $, Cerebras est revenue à son prix d'entrée de 185 $. Côté startups, la French Tech a levé 114 M€ la semaine du 21 septembre, dont 90 M€ dans l'IA.",
  "actions": [
    {
      "type": "ACHETER",
      "cible": "SpaceX (+ Cursor)",
      "ticker": "SPCX",
      "montantEUR": 350,
      "enBref": "Acheter une première tranche de 350 € maintenant, garder le reste pour décembre.",
      "these": "SpaceX est la seule « startup en explosion » que tu peux acheter directement sur Trade Republic. Après une entrée en bourse record, l'action a perdu environ 35 % depuis son sommet : tu paies nettement moins cher que les acheteurs de juillet. Elle possède aussi Cursor, un des logiciels à la croissance la plus rapide jamais vue. Mais début décembre, les investisseurs d'avant la cotation pourront vendre leurs actions, ce qui peut faire baisser le cours : d'où un achat en deux fois.",
      "pour": [
        {
          "point": "Le prix a déjà beaucoup baissé depuis l'euphorie de juillet",
          "chiffre": "Sommet vers 226 $, 145,47 $ le 28/09/2026 (-35 %)",
          "source": "https://www.fool.com/investing/2026/07/27/spacex-stock-plummets-50-below-its-post-ipo-high-h/"
        },
        {
          "point": "Plus grosse introduction en bourse de l'histoire, preuve d'une demande énorme",
          "chiffre": "75 Md$ levés le 12/06/2026 à environ 1 770 Md$ de valorisation",
          "source": "https://dealroom.net/blog/upcoming-recent-ipos"
        },
        {
          "point": "Possède Cursor, l'outil de code par IA qui grandit le plus vite",
          "chiffre": "Rachat pour 60 Md$ bouclé le 14/08/2026, environ 4 Md$ de revenu annuel estimé",
          "source": "https://getlatka.com/companies/cursor.com"
        }
      ],
      "contre": [
        {
          "point": "Les investisseurs d'avant l'IPO pourront vendre à partir de début décembre",
          "chiffre": "Blocage de 180 jours, levé par étapes",
          "source": "https://en.wikipedia.org/wiki/Initial_public_offering_of_SpaceX"
        },
        {
          "point": "L'entreprise s'endette pour financer ses projets",
          "chiffre": "Emprunt obligataire porté de 20 à 25 Md$",
          "source": "https://en.wikipedia.org/wiki/Initial_public_offering_of_SpaceX"
        },
        {
          "point": "Valorisation énorme : une grande partie de la croissance future est déjà dans le prix",
          "chiffre": null,
          "source": null
        }
      ],
      "plan": "350 € maintenant. 650 € en décembre–janvier, après la levée du blocage, idéalement en 2 fois. Si le cours repasse sous son prix d'entrée (135 $), c'est une meilleure occasion.",
      "horizon": "3 à 5 ans",
      "confiance": "moyenne",
      "sources": [
        {
          "titre": "Motley Fool : SpaceX 50 % sous son sommet",
          "url": "https://www.fool.com/investing/2026/07/27/spacex-stock-plummets-50-below-its-post-ipo-high-h/"
        },
        {
          "titre": "Wikipedia : introduction en bourse de SpaceX",
          "url": "https://en.wikipedia.org/wiki/Initial_public_offering_of_SpaceX"
        },
        {
          "titre": "Dealroom : IPO 2026",
          "url": "https://dealroom.net/blog/upcoming-recent-ipos"
        }
      ]
    },
    {
      "type": "ACHETER",
      "cible": "Cerebras",
      "ticker": "CBRS",
      "montantEUR": 250,
      "enBref": "Petite ligne de 250 €, maintenant revenue au prix d'entrée en bourse.",
      "these": "Cerebras fabrique des puces spécialisées pour l'IA, une alternative à Nvidia. Après son entrée en bourse, le cours a dépassé 300 $ puis est revenu à son prix d'introduction : tu peux entrer au prix des premiers investisseurs plutôt qu'au sommet. C'est un pari plus risqué que SpaceX, donc une petite ligne.",
      "pour": [
        {
          "point": "Cours revenu au prix d'introduction après l'euphorie",
          "chiffre": "IPO à 185 $ le 14/05/2026, plus de 300 $ ensuite, retour à 185 $ fin août",
          "source": "https://www.superhero.com.au/learn/upcoming-ipos-2026/"
        },
        {
          "point": "Le marché des puces pour l'IA continue de croître avec les besoins des labos",
          "chiffre": null,
          "source": null
        }
      ],
      "contre": [
        {
          "point": "Très volatil : il peut encore perdre beaucoup",
          "chiffre": "-40 % du sommet en 3 mois",
          "source": "https://www.superhero.com.au/learn/upcoming-ipos-2026/"
        },
        {
          "point": "Face à Nvidia et aux puces maison des géants du cloud",
          "chiffre": null,
          "source": null
        }
      ],
      "plan": "250 € maintenant, puis éventuellement 250 € dans un mois si les nouvelles restent bonnes. Vérifie d'abord que CBRS est proposée dans l'appli Trade Republic.",
      "horizon": "3 à 5 ans",
      "confiance": "faible",
      "sources": [
        {
          "titre": "Superhero : IPO 2026",
          "url": "https://www.superhero.com.au/learn/upcoming-ipos-2026/"
        }
      ]
    },
    {
      "type": "ATTENDRE",
      "cible": "Réserve pour les prochaines entrées en bourse",
      "ticker": null,
      "montantEUR": null,
      "enBref": "Garder 1 000 € en espèces pour les introductions en bourse de fin d'année, et ne pas acheter le premier jour.",
      "these": "Plusieurs grosses sociétés préparent leur entrée en bourse. L'expérience de 2025-2026 montre que le prix grimpe souvent les premiers jours puis redescend. Attendre au moins 30 jours après la cotation évite d'acheter au sommet.",
      "pour": [
        {
          "point": "Plusieurs grosses IPO arrivent (Oura, Notion, OpenEvidence, Kraken…)",
          "chiffre": "8 candidates à une IPO dans les 6 mois selon Crunchbase (02/09/2026)",
          "source": "https://news.crunchbase.com/public/startups-to-watch-ipo-ai-chips-fintech-2026/"
        },
        {
          "point": "Les IPO récentes ont souvent reculé après l'euphorie",
          "chiffre": "SpaceX et Cerebras revenues près de leur prix d'entrée",
          "source": "https://www.superhero.com.au/learn/upcoming-ipos-2026/"
        }
      ],
      "contre": [
        {
          "point": "En attendant, l'argent ne rapporte presque rien",
          "chiffre": null,
          "source": null
        },
        {
          "point": "Les dates d'introduction changent souvent (OpenAI repoussée à 2027)",
          "chiffre": null,
          "source": "https://www.allocations.com/insights/spacex-openai-anthropic-stripe-databricks-ipo-timeline-2026"
        }
      ],
      "plan": "Laisse 1 000 € sur Trade Republic. Quand une IPO t'intéresse, attends 30 jours après la cotation et compare le cours au prix d'introduction avant d'acheter.",
      "horizon": "3 à 6 mois",
      "confiance": "moyenne",
      "sources": [
        {
          "titre": "Crunchbase : 8 startups à surveiller pour une IPO",
          "url": "https://news.crunchbase.com/public/startups-to-watch-ipo-ai-chips-fintech-2026/"
        },
        {
          "titre": "Allocations : calendrier des IPO 2026",
          "url": "https://www.allocations.com/insights/spacex-openai-anthropic-stripe-databricks-ipo-timeline-2026"
        }
      ]
    },
    {
      "type": "ACHETER",
      "cible": "Startups françaises (crowdequity)",
      "ticker": null,
      "montantEUR": 500,
      "enBref": "Commencer ta sélection : 2 startups à 250 € ce trimestre, 8 à 10 au total sur 18 mois.",
      "these": "C'est là que se font les multiplications par 10, et l'État te rembourse une partie en réduction d'impôt. Mais la plupart des jeunes startups échouent : il faut en prendre au moins 8 à 10 et ne garder que les dossiers qui passent ta grille de 8 vérifications (onglet Mes dossiers).",
      "pour": [
        {
          "point": "Réduction d'impôt sur le montant investi",
          "chiffre": "18 % en 2026, 30 % pour une Jeune Entreprise Innovante, 50 % pour une JEI de rupture",
          "source": "https://lita.co/fr/defiscaliser-investissement/ir-pme"
        },
        {
          "point": "L'IA française attire beaucoup d'argent professionnel",
          "chiffre": "90 M€ levés par 9 startups d'IA la semaine du 21/09/2026",
          "source": "https://www.maddyness.com/2026/09/25/les-startups-francaises-ont-leve-114-millions-deuros-cette-semaine-dont-90-millions-dans-lia/"
        }
      ],
      "contre": [
        {
          "point": "Argent bloqué longtemps, sans revente possible",
          "chiffre": "5 à 10 ans, et 5 ans minimum pour garder la réduction d'impôt",
          "source": "https://lita.co/fr/defiscaliser-investissement/ir-pme"
        },
        {
          "point": "Une grande partie des jeunes startups ne survit pas",
          "chiffre": null,
          "source": null
        }
      ],
      "plan": "250 € par startup, jamais plus de 2 par trimestre. N'investis que si le dossier obtient 6/8 ou plus dans « Mes dossiers » et que la plateforme est sur la liste blanche de l'AMF.",
      "horizon": "5 à 10 ans",
      "confiance": "moyenne",
      "sources": [
        {
          "titre": "Lita : réduction d'impôt IR-PME 2026",
          "url": "https://lita.co/fr/defiscaliser-investissement/ir-pme"
        },
        {
          "titre": "Maddyness : levées de la semaine",
          "url": "https://www.maddyness.com/2026/09/25/les-startups-francaises-ont-leve-114-millions-deuros-cette-semaine-dont-90-millions-dans-lia/"
        }
      ]
    }
  ],
  "alertes": [
    "30/09/2026 : dernier jour pour la réduction d'impôt de 25 % sur les entreprises solidaires (ESUS). Ensuite, retour à 18 %.",
    "Novembre 2026 : introduction en bourse d'Anthropic annoncée (repoussée d'octobre). Aucune recommandation ici, l'IA de l'app étant développée par Anthropic.",
    "Début décembre 2026 : les investisseurs d'avant l'IPO de SpaceX peuvent commencer à vendre."
  ],
  "verifications": [
    "Renseigne ton patrimoine total dans Réglages pour que la jauge et les analyses dosent correctement.",
    "Vérifie que SPCX et CBRS sont disponibles dans ton appli Trade Republic, et le prix affiché avant de valider.",
    "Avant toute plateforme de crowdequity, vérifie qu'elle est agréée sur amf-france.org.",
    "Ces montants sont un exemple de départ : l'analyse automatique du matin les ajuste à tes réglages."
  ]
};
